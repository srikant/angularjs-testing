
'use strict';

function Expense(expenseItem) {
    this.expenseItem = expenseItem;
}

