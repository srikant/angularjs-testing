
function ExpenseItem(expenseAmount) {
    this.amount = expenseAmount;
}