/**
 * Created by Jesse on 3/22/2014.
 */
function ExpenseEntry() {}