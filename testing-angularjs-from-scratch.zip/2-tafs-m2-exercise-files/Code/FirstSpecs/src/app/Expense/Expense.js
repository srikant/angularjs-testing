/**
 * Created by Jesse on 3/22/2014.
 */
function Expense(expenseEntry){
    this.expenseEntry = expenseEntry;

};