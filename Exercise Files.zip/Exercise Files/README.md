# Testing AngularJS Screencast

This repo contains all the code created for the Testing AngularJS Screencast. Rudolf Olah recorded the screencast and wrote the code. Employees of Packt Publishing edited the screencast and published it.
