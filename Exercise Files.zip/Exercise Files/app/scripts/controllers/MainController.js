angular
  .module('pizzaStore')
  .controller('MainController', function($scope) {
  });
