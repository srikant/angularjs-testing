describe("Given the Angular Feedreader app", function () {
  
  beforeEach(function () {
    angular.mock.module('myApp');
  });
  
  it("When initialized, it should set the title", inject(function ($rootScope){
    expect($rootScope).toBeDefined();
    expect($rootScope.title).toBeDefined();
  }));
  
  describe("Given the controller 'myCtrl'", function () {
    
    var ctrl; 
    
    beforeEach(inject (function ($controller) {
      ctrl = $controller('myCtrl');
    }));
    
    it("When the app is initialized, it should create the controller", function () {
      expect(ctrl).toBeDefined();
    });
    
    describe("When the controller is initialized, it", function () {
      
      it("Should set the default URL", function () {
        expect(ctrl.url).toBeDefined();
      });
      
      it("Should not have the feed property set", function () {
        expect(ctrl.feed).toBeUndefined();
      });
      
      it("Should expose a function to process the URL", function (){
        expect(ctrl.process).toBeDefined();
        expect(angular.isFunction(ctrl.process)).toBe(true);
      });
      
      it("Should contain a reference to the rssFeed service", function () {
        expect(ctrl.rssFeed).toBeDefined();
      });
      
      describe("When the process function is called, it", function () {
        
        beforeEach(inject (function (rssFeed) {
          
          spyOn(rssFeed, 'fetch').and.callReturn({
            then: function(callback) { callback(123); }
          });
          
          ctrl.process();
          
        }));
        
        it("Should call the fetch method on the rssFeed service", function () {
          expect(ctrl.rssFeed.fetch).toHaveBeenCalled();
        });
        
        it("Should set the feed property to the value returned by the promise", function () {
          expect(ctrl.feed).toBe(123);
        });
        
      });
      
    });
    
  });
  
  describe("Given the service 'rssFeed'", function () {
    
    var service, httpBackend;
    
    beforeEach(inject( function(rssFeed, $httpBackend) {
      service = rssFeed;
      httpBackend = $httpBackend;
    }));
    
    it("When the app is initialized, it should create the service", function () {
      expect(service).toBeDefined();
    });
    
    describe("When the service is initialized, it", function () {
      
      it("Should have a reference to the $q service", function () {
        expect(service.$q).toBeDefined();
      });
      
      it("Should have a reference to the $http service", function () {
        expect(service.$http).toBeDefined();
      });
      
      it("Should expose a function to process the feed", function (){
        expect(service.fetch).toBeDefined();
        expect(angular.isFunction(service.fetch)).toBe(true);
      });
      
      describe("When the fetch function is called, it", function () {
        
        beforeEach(function () {
          
          httpBackend.expectJSONP("https://ajax.googleapis.com/ajax/services/feed/load?v=1.0&q=http://feeds.feedburner.com/CSharperImage&callback=JSON_CALLBACK")
          .respond(200, { responseData: { feed: {}}});
          
          spyOn(service.$http, 'jsonp').and.callThrough();
        });
        
        it("Should return a promise that is resolved from a call to $http.jsonp", function (done) {
          service.fetch("http://feeds.feedburner.com/CSharperImage")
          .then(function (res) {
            expect(res).toBeDefined();
            expect(service.$http.jsonp).toHaveBeenCalled();
            done();
          });
          
          httpBackend.flush();
        });
        
      });
      
    });
  });
});