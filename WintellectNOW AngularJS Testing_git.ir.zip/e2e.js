describe("End-to-End Test", function() {
  
  beforeEach(function () {
    browser().navigateTo("app.html");
  })
  
  it("Should load a feed when the button is clicked", function () {
    
    element('button').click(); 
    expect(element('#feedDescription').text()).toContain('Author');
    
  });
  
});