// Code goes here
(function (app) {
  
  app.run(['$rootScope', function ($rootScope) {
    $rootScope.title = 'Angular Feedreader';
  }]);
  
  app.controller('myCtrl', ['rssFeed', function (rssFeed) {
    
    var _this = this;
    this.rssFeed = rssFeed;
    this.url = 'http://feeds.feedburner.com/CSharperImage';
    
    this.process = function () {
      _this.rssFeed.fetch(_this.url)
        .then(function (res) {
          _this.feed = res;
        });
    };
    
  }]);
  
  app.service('rssFeed', ['$q', '$http', function ($q, $http) {
    
    var _this = this; 
    this.$q = $q;
    this.$http = $http;
  
    this.fetch = function (url) {
      
      var deferral = _this.$q.defer();
      
      _this.$http.jsonp("https://ajax.googleapis.com/ajax/services/feed/load?v=1.0&q="
        + url + "&callback=JSON_CALLBACK")
        
        .then(function (response) {
          deferral.resolve(response.data.responseData.feed);
        }, 
        
        function(error) {
          deferral.reject(error);
        });
        
        return deferral.promise;
    };
    
  }]);
  
})(angular.module('myApp', []));